# Map My Heritage - Components Guide

This folder contains reusable components and styling information for the Map My Heritage website. Use these components to maintain consistency across all pages.

## Files Included

1. **navbar.html** - The navigation bar component
2. **colors.css** - Color scheme and styling information
3. **template.html** - A template for creating new pages
4. **images/logo2-removebg-preview.png** - The website logo

## How to Use These Components

### Using the Navbar

Copy the navbar code from `navbar.html` and paste it into your HTML file. Make sure to:

1. Update the `active` class on the appropriate nav item
2. Ensure the paths to images and CSS files are correct

Example:
```html
<!-- Include the navbar at the top of your body tag -->
<nav class="navbar navbar-expand-lg navbar-light bg-white fixed-top">
    <!-- Navbar content -->
</nav>
```

### Using the Logo

The logo is included in the `images` folder within the components directory. When using the navbar or template, the logo path is already set correctly. If you need to use the logo elsewhere:

```html
<img src="images/logo2-removebg-preview.png" alt="Map My Heritage Logo" width="40" height="40">
```

### Using the Color Scheme

Include the `colors.css` file in your HTML:

```html
<link rel="stylesheet" href="../css/colors.css">
```

This file contains CSS variables that you can use in your own CSS:

```css
.my-element {
    color: var(--primary-color);
    background-color: var(--bg-light);
}
```

### Using the Template

1. Copy the `template.html` file
2. Rename it to your page name (e.g., `about.html`)
3. Update the title, content, and active nav item
4. Add your page-specific content

## Color Palette

- **Primary Color**: #D9534F (Brick Red)
- **Text Dark**: #434A54 (Dark Charcoal)
- **Text Medium**: #6c757d (Medium Gray)
- **Text Light**: #8c8c8c (Light Gray)
- **Background Light**: #F5F7FA (Light Gray)
- **Rating Color**: #FFD700 (Gold)

## Typography

- **Headings**: Montserrat (Bold)
- **Body Text**: Roboto (Regular)

## Best Practices

1. **Consistency**: Use the provided components and colors to maintain a consistent look and feel
2. **Responsiveness**: Ensure all pages are responsive and work well on mobile devices
3. **Accessibility**: Use semantic HTML and ensure sufficient color contrast
4. **Performance**: Optimize images and minimize CSS/JavaScript

## Need Help?

If you have questions about using these components, please contact the project lead. 